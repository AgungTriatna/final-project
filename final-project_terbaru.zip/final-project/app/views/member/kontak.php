<h3>Hubungi Kami</h3>
<hr>
<div class="card shadow">
    <div class="card-body">
        <p>Jika mengalami Kendala silahkan hubungi kami.</p>
        <b>
            <p>Whatsapp</p>
        </b>
        <p>081983733783</p>
        <b>
            <p>Email</p>
        </b>
        <p>email@perusahaan.com</p>
        <b>
            <p>Telp / Fax</p>
        </b>
        <p>(0361)88432222</p>
        <p>Terima kasih telah menggunakan layanan Apps perusahaan !</p>
    </div>
</div>