</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->
<!-- Footer -->
<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; Kelompok 2</span>
        </div>
    </div>
</footer>
<!-- End of Footer -->
</div>
<!-- End of Content Wrapper -->
</div>
<!-- End of Page Wrapper -->
<script src="<?= BASEURL ?>/js/jquery.min.js"></script>
<script src="<?= BASEURL ?>/js/bootstrap.min.js"></script>
<script src="<?= BASEURL ?>/js/member-ajax.js"></script>
<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.2.4/js/dataTables.responsive.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.2.4/js/responsive.bootstrap4.min.js"></script>
<script type="text/javascript">
    $('#tbl-daftar-pinjaman').DataTable();
    $('#tbl-daftar-user').DataTable();
    $('#tbl-daftar-barang').DataTable();
    $('#tbl-list-departement').DataTable();
</script>
<!-- Custom scripts for all pages-->
<script src="<?= BASEURL ?>/js/sb-admin-2.min.js"></script>
</body>

</html>