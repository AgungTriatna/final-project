</div>
    <script src="<?= BASEURL ?>/js/jquery.min.js"></script>
    <script src="<?= BASEURL ?>/js/bootstrap.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="<?= BASEURL ?>/js/sb-admin-2.min.js"></script>
</body>

</html>